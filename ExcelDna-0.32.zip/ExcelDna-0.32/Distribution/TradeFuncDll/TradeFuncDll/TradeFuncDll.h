#include <stdexcept>
using namespace std;

namespace TradeFuncs
{
	extern "C" {__declspec(dllexport) void *prody(double *results, double *data1, double *data2, int nrows, int ncols);}
	extern "C" {__declspec(dllexport) void *expy(double *results, double *data1, double *data2, int nrows, int ncols);}
	extern "C" {__declspec(dllexport) void *rca(double *results, double *data1, double *data2, int nrows, int ncols);}
}
