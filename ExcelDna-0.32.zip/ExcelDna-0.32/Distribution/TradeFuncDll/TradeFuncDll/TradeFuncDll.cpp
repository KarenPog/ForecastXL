// TradeFuncDll.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "TradeFuncDll.h"
namespace TradeFuncs
{
void * prody(double *results, double *data1, double *data2, int nrows, int ncols)
{
	int i,j;	
	
	double *sum1;
	sum1 = new double [nrows];

for (i = 0; i < ncols;i++)

{
sum1[i] = 0.0;	
	for (j=0;j<nrows;j++)
	{
		sum1[i] += data1[i+j*ncols];	
	}	
}

double **matrix;
matrix = new double* [nrows];
for (int i = 0; i < nrows; i++)
matrix[i] = new double[ncols];
for (i=0;i<ncols;i++)
{
	for (j=0;j<nrows;j++)
	{
		matrix[j][i] = data1[i+j*ncols]/sum1[i];
	}
}

double *sum2;
sum2 = new double [nrows];
for (i = 0; i < nrows;i++)
{
sum2[i] = 0.0;	
	for (j=0;j<ncols;j++)
	{
		sum2[i] += matrix[i][j];    
	}
}

double *matrix2;
matrix2 = new double [nrows*ncols];

for (i=0;i<ncols;i++)
{
	for (j=0;j<nrows;j++)
	{
		matrix2[i + j*ncols] = matrix[j][i]/sum2[j];
	}
}

for (i=0;i<nrows;i++)
{
	results[i]=0.0;
	for (j=0;j<ncols;j++)
	{
		
		results[i] += matrix2[j + i*ncols]*data2[j];
	}
}

for (i=0;i<nrows;i++)
{
if (results[i]!=results[i])
{
    results[i] = 0.0;
}
}
	return results;
}

void * expy(double *results, double *data1, double *data2, int nrows, int ncols)
{
int i,j;	
	double *sum1;
	sum1 = new double [ncols];

for (i = 0; i < ncols;i++)

{
sum1[i] = 0.0;	
	for (j=0;j<nrows;j++)
	{
		sum1[i] += data1[i+j*ncols];	
	}	
}

double **matrix;
matrix = new double* [nrows];
for (int i = 0; i < nrows; i++)
matrix[i] = new double[ncols];
for (i=0;i<ncols;i++)
{
	for (j=0;j<nrows;j++)
	{
		matrix[j][i] = data1[i+j*ncols]/sum1[i];
	}
}

double *res_prody;
res_prody = new double [nrows];
prody(res_prody,data1,data2, nrows,ncols);

for (i=0;i<ncols;i++)
{
	results[i]=0.0;
	for (j=0;j<nrows;j++)
	{		
		results[i] +=  matrix[j][i]*res_prody[j];
	}
}
return results;

}

void * rca(double *results, double *data1, double *data2, int nrows, int ncols)
{
int i,j;	
	double *sum1;
	sum1 = new double [ncols];

for (i = 0; i < ncols;i++)

{
sum1[i] = 0.0;	
	for (j=0;j<nrows;j++)
	{
		sum1[i] += data1[i+j*ncols];	
	}	
}

double **matrix;
matrix = new double* [nrows];
for (int i = 0; i < nrows; i++)
matrix[i] = new double[ncols];

for (i=0;i<ncols;i++)
{
	for (j=0;j<nrows;j++)
	{
		matrix[j][i] = data1[i+j*ncols]/sum1[i];
	}
}

double sum2 = 0.0;
for (i = 0; i < nrows;i++)
{	
	sum2 += data2[i];	
}

double *vector;
vector = new double [nrows];

for (i=0;i<nrows;i++)
{	
	vector[i] = data2[i]*(1.0/sum2);	
}

for (i=0;i<ncols;i++)
{	
	for (j=0;j<nrows;j++)
	{		
		results[j+i*nrows] = matrix[j][i]/vector[j];
	}	
}
return results;
}
}

